function [Coef]= CSIgen (Ntot,T,M,Fdm,Slot,BW,Mode)
if nargin==0
    Ntot=10;T=1e5;M=3;Fdm=5;Slot=1e-3;BW=0.01;Mode='PedB';
end
Jake_No=32;Jake_N=4*Jake_No;
if (M>Jake_No&&strcmp(Mode,'DelF'))||(M>Jake_No/6&&strcmp(Mode,'VehB'))||(M>Jake_No/6&&strcmp(Mode,'PedB'))
    display(['The number of SUs is larger than' num2str(strcmp(Mode,'dftao')*Jake_No+strcmp(Mode,'VehB')*floor(Jake_No/6)) '!']);
    
    return
end
Walsh=walshcode(log2(Jake_No));
Jake_Alpha=2.*pi.*((1:Jake_No)-0.5)./Jake_N;% Jake_Alpha=2*pi*rand(1,Jake_No);
Jake_Fn=Fdm.*cos(Jake_Alpha);
Jake_Beta=pi.*(1:Jake_No)./Jake_No;
switch Mode
    case'DelF'
        dftao=BW;
        Scale=sqrt(2./Jake_No);
        Coef=zeros(Ntot,T,M);
        for m=1:M
            ProductOfDelayTimeDeltaF=exprnd(dftao,1,Jake_No);
            for t=0:T-1
                for k=0:Ntot-1
                    Coef(k+1,t+1,m)=sum(Walsh(m,:).*cos(2.*pi.*Jake_Fn.*t.*Slot).*exp(1j.*Jake_Beta).*exp(-2j.*pi.*ProductOfDelayTimeDeltaF.*k)).*Scale;
                end
            end
        end
    case 'Indp'
        Scale=sqrt(2./Jake_No);
        Coef=zeros(Ntot,T,M);
        for m=1:M
            for  t=0:T-1
                for k=0:Ntot-1
                    Coef(k+1,t+1,m)=sum(Walsh(k*M+m,:).*cos(2.*pi.*Jake_Fn.*t.*Slot).*exp(1j.*Jake_Beta)).*Scale;
                end
            end
        end
    case 'VehB'
        VehB_Delay=[0 300e-9 8900e-9 12900e-9 17100e-9 20000e-9];
        VehB_AmpdB=[-2.5 0 -12.8 -10.0 -25.2 -16.0];
        VehB_Amp=db2mag(VehB_AmpdB);
        Scale=1/sqrt(sum(VehB_Amp.^2)).*sqrt(2./Jake_No);
        for m=1:M
            for t=0:T-1
                c=zeros(1,6);
                for p=(1:6)+(m-1).*6
                    c(p-(m-1).*6)=sum(Walsh(p,:).*cos(2.*pi.*Jake_Fn.*t.*Slot).*exp(1j.*Jake_Beta));
                end
                for k=0:Ntot-1
                    Coef(k+1,t+1,m)=sum(VehB_Amp.*c.*exp(-2j.*pi.*VehB_Delay.*BW.*k)).*Scale;
                end
            end
        end
    case 'VehA'
        VehA_Delay=[0 310e-9 710e-9 1090e-9 1730e-9 2510e-9];
        VehA_AmpdB=[0 -1 -9 -10 -15 -20];
        VehA_Amp=db2mag(VehA_AmpdB);
        Scale=1/sqrt(sum(VehA_Amp.^2)).*sqrt(2./Jake_No);
        for m=1:M
            for t=0:T-1
                c=zeros(1,6);
                for p=(1:6)+(m-1).*6
                    c(p-(m-1).*6)=sum(Walsh(p,:).*cos(2.*pi.*Jake_Fn.*t.*Slot).*exp(1j.*Jake_Beta));
                end
                for k=0:Ntot-1
                    Coef(k+1,t+1,m)=sum(VehA_Amp.*c.*exp(-2j.*pi.*VehA_Delay.*BW.*k)).*Scale;
                end
            end
        end
    case 'PedB'
        PedB_Delay=[0 200e-9 800e-9 1200e-9 2300e-9 3700e-9];
        PedB_AmpdB=[0 -0.9 -4.9 -8 -7.8 -23.9];
        PedB_Amp=db2mag(PedB_AmpdB);
        Scale=1/sqrt(sum(PedB_Amp.^2)).*sqrt(2./Jake_No);
        for m=1:M
            for t=0:T-1
                c=zeros(1,6);
                for p=(1:6)+(m-1).*6
                    c(p-(m-1).*6)=sum(Walsh(p,:).*cos(2.*pi.*Jake_Fn.*t.*Slot).*exp(1j.*Jake_Beta));
                end
                for k=0:Ntot-1
                    Coef(k+1,t+1,m)=sum(PedB_Amp.*c.*exp(-2j.*pi.*PedB_Delay.*BW.*k)).*Scale;
                end
            end
        end
end
end


%% Walsh Code Generator
function [op_code] = walshcode(a)
len_walsh = 2 .^ a;  %length of walsh code , and number of walsh codes
walsh_code = 1;
i = 2;
while (i <= len_walsh)
    walsh_code = [walsh_code, walsh_code ; walsh_code, -1.* walsh_code];
    i = i.*2;
end
op_code = walsh_code;
end