function conditionPDF=calconditionalPDF(SNR,avgSNR,SNR_hat,rho)
x=2.*sqrt(SNR*SNR_hat)./avgSNR./(1-rho);
indexAccurate=find(x<=600);
indexApprox=find(x>600);
conditionPDF=zeros(1,length(SNR));
conditionPDF(indexAccurate)=1./avgSNR./(1-rho).*besseli(0,x(indexAccurate)).*exp(-1./avgSNR/(1-rho).*(SNR(indexAccurate)+SNR_hat));
y=(2.*sqrt(SNR(indexApprox).*SNR_hat)-SNR(indexApprox)-SNR_hat)./avgSNR./(1-rho);
conditionPDF(indexApprox)=1./avgSNR./(1-rho).*exp(y)./sqrt(2*pi*x(indexApprox)).*(1+1./(8*x(indexApprox))+9./(128*x(indexApprox).^2)+225./(3072*x(indexApprox).^3)+11025./(98304*x(indexApprox).^4)+893025./(3932160*x(indexApprox).^5));
end
