clc;clear all;close all force;
nSU=3;
T=20;
nCh=10;
p01=0.2.*ones(1,nCh);
p11=0.8.*ones(1,nCh);
MAX=1e3;% Change to MAX=1e4 to get exactly Fig.5
Traffic=0;
Fade=cell(2);
Fade{1}=1;
Pm=0;Pf=0;
avgSNRdBrange=10:30;
avgSNRrange=db2pow(avgSNRdBrange);
NCCmin=1;
NCCmax=10;
h = waitbar(0,'Please wait...');
for i=1:length(avgSNRdBrange)
    waitbar(i/length(avgSNRdBrange),h)
avgSNR=avgSNRrange(i);
Fade{2}=avgSNR;
Metric=0;Randomize{1}=0;Belief=3;Reward=2;
[avg_SU_Greedytemp,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
avg_SU_Greedy(i)=sum(avg_SU_Greedytemp)./T;
Metric=0;Randomize{1}=1;Belief=3;
[avg_SU_Randomizetemp,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
avg_SU_Randomize(i)=sum(avg_SU_Randomizetemp)./T;
Metric=2;Randomize{1}=0;Belief=3;
[avg_SU_CSItemp,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
avg_SU_CSI(i)=sum(avg_SU_CSItemp)./T;
Metric=0;Randomize{1}=0;Belief=0;
[avg_SU_randomtemp,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX, Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
avg_SU_random(i)=sum(avg_SU_randomtemp)./T;
Metric=0;Randomize={4,NCCmin,NCCmax};Belief=3;
[avg_SU_GreedyCAtemp,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX, Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
avg_SU_GreedyCA(i)=sum(avg_SU_GreedyCAtemp)./T;
Metric=0;Randomize{1}=2;Belief=3;
[avg_SU_FCFStemp,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
avg_SU_FCFS(i)=sum(avg_SU_FCFStemp)./T;
Metric=0;Randomize{1}=3;Belief=3;
[avg_SU_TDFStemp,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
avg_SU_TDFS(i)=sum(avg_SU_TDFStemp)./T;
Metric=2;Randomize{1}=2;Belief=3;
[avg_SU_CSI_FCFStemp,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
avg_SU_CSI_FCFS(i)=sum(avg_SU_CSI_FCFStemp)./T;
Metric=2;Randomize{1}=3;Belief=3;
[avg_SU_CSI_TDFStemp,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
avg_SU_CSI_TDFS(i)=sum(avg_SU_CSI_TDFStemp)./T;
end
%% Plot results
figure;
s(1)=subplot(1,1,1);
plot(avgSNRdBrange,avg_SU_CSI_FCFS,'r-');hold on;
plot(avgSNRdBrange(1:3:end),avg_SU_CSI_FCFS(1:3:end),'rs');hold on;
h(1)=plot(avgSNRdBrange(1),avg_SU_CSI_FCFS(1),'r-s');hold on;

plot(avgSNRdBrange,avg_SU_CSI_TDFS,'r-');hold on
plot(avgSNRdBrange(1:3:end),avg_SU_CSI_TDFS(1:3:end),'ro');hold on
h(2)=plot(avgSNRdBrange(1),avg_SU_CSI_TDFS(1),'r-o');hold on

plot(avgSNRdBrange,avg_SU_CSI,'r-');hold on;
plot(avgSNRdBrange(1:3:end),avg_SU_CSI(1:3:end),'rx','MarkerSize', 10);hold on;
h(3)=plot(avgSNRdBrange(1),avg_SU_CSI(1),'r-x','MarkerSize', 10);hold on;

plot(avgSNRdBrange,avg_SU_FCFS,'b--');hold on;
plot(avgSNRdBrange(1:3:end),avg_SU_FCFS(1:3:end),'bs');hold on;
h(4)=plot(avgSNRdBrange(1),avg_SU_FCFS(1),'b--s');hold on;

plot(avgSNRdBrange,avg_SU_GreedyCA,'b--');hold on;
plot(avgSNRdBrange(1:3:end),avg_SU_GreedyCA(1:3:end),'bv','MarkerSize', 7);hold on;
h(5)=plot(avgSNRdBrange(1),avg_SU_GreedyCA(1),'b--v','MarkerSize', 7);hold on;

plot(avgSNRdBrange,avg_SU_TDFS,'b-');hold on
plot(avgSNRdBrange(1:3:end),avg_SU_TDFS(1:3:end),'b+','MarkerSize', 10);hold on
h(6)=plot(avgSNRdBrange(1),avg_SU_TDFS(1),'b-+','MarkerSize', 10);hold on;
plot(avgSNRdBrange,avg_SU_Greedy,'b--');hold on;
plot(avgSNRdBrange(1:3:end),avg_SU_Greedy(1:3:end),'bx','MarkerSize', 10);hold on;
h(7)=plot(avgSNRdBrange(1),avg_SU_Greedy(1),'b--x','MarkerSize', 10);hold on;

h(8)=plot(avgSNRdBrange,avg_SU_Randomize,'k--');hold on;
h(9)=plot(avgSNRdBrange,avg_SU_random,'k-');hold on;
ylim([0.5,6])
ylabel({'Normalized Network Throughput';'(bits/s)/Hz/SU'});
xlabel('Average SNR (dB)');
grid on
ah1 = gca;
legend(ah1,h(1:3),'Location',[0.158895502645501 0.760692239858915 0.429563492063491 0.135030864197531],'{(viii)} Myopic (CSI-aided, FCFS)','{(vii)} Myopic (CSI-aided, TDFS)','{(vi)}  Myopic (CSI-aided)',1);
ah2=axes('position',get(gca,'position'), 'visible','off');
legend(ah2,h([4,5,7]),'Location',[0.158895502645501 0.5761684303351 0.300099206349206 0.135030864197531],'{(iv)} Myopic (FCFS)','Myopic (CA) ','{(ii)} Myopic','Location','Best',2);
ah3=axes('position',get(gca,'position'), 'visible','off');
legend(ah3,h([8,6,9]),'Location',[0.610945767195763 0.161816578483246 0.300099206349206 0.135030864197531],'(v) Randomized','(iii) Myopic (TDFS)','(i) Random','Location','Best',3);
PPP1=get(s(1),'pos');
PPP1(3)=PPP1(3)+0.04;
set(s(1),'pos',PPP1)