clc;clear all;
nSU=3;
T=20;
nCh=10;
p01=0.2.*ones(1,nCh);
p11=0.8.*ones(1,nCh);
MAX=1e3;% Change to MAX=1e4 to get exactly Fig.4
Pm=0;Pf=0;
avgSNRdB=10;
Fade=cell(2);
Fade{1}=1;
Fade{2}=db2pow(avgSNRdB);
Reward=1;
Metric=0;Randomize{1}=0;Belief=3;
[avg_SU_Greedy,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
NCCmin=1;
NCCmax=10;
Metric=0;Randomize={4,NCCmin,NCCmax};Belief=3;
[avg_SU_GreedyCA,~,avg_Se]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
Metric=0;Randomize{1}=1;Belief=3;
[avg_SU_Randomize,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
Metric=1;Randomize{1}=0;Belief=3;
[avg_SU_CSI,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
Metric=1;Randomize{1}=2;Belief=3;
[avg_SU_CSI_FCFS,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
Metric=1;Randomize{1}=3;Belief=3;
[avg_SU_CSI_TDFS,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
Metric=0;Randomize{1}=2;Belief=3;
[avg_SU_FCFS,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
Metric=0;Randomize{1}=3;Belief=3;
[avg_SU_TDFS,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);
Metric=0;Randomize{1}=0;Belief=0;
[avg_SU_random,~,~]=Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief);

%% Plot results
close all;
figure;s(1)=subplot(1,1,1);
temp=cumsum(avg_SU_CSI_FCFS)./(1:T);
plot(1:T,temp,'r-');hold on;
plot(3:3:T,temp(3:3:end),'rs');hold on;
h(1)=plot(3,temp(3),'r-s');hold on;

temp=cumsum(avg_SU_CSI_TDFS)./(1:T);
plot(1:T,temp,'r-');hold on
plot(3:3:T,temp(3:3:end),'ro');hold on
h(2)=plot(3,temp(3),'r-o');hold on

temp=cumsum(avg_SU_CSI)./(1:T);
plot(1:T,temp,'r-');hold on
plot(3:3:T,temp(3:3:end),'rx','MarkerSize', 10);hold on
h(3)=plot(3,temp(3),'r-x','MarkerSize', 10);hold on

temp=cumsum(avg_SU_FCFS)./(1:T);
plot(1:T,temp,'b--');hold on
plot(3:3:T,temp(3:3:end),'bs');hold on
h(4)=plot(3,temp(3),'b--s');hold on

temp=cumsum(avg_SU_GreedyCA)./(1:T);
plot(1:T,temp,'b--');hold on
plot(3:3:T,temp(3:3:end),'bv','MarkerSize', 7);hold on
h(5)=plot(3,temp(3),'b--v','MarkerSize', 7);hold on

temp=cumsum(avg_SU_TDFS)./(1:T);
plot(1:T,temp,'b-');hold on
plot(3:3:T,temp(3:3:end),'b+','MarkerSize', 9);hold on
h(6)=plot(3,temp(3),'b-+','MarkerSize', 9);hold on
temp=cumsum(avg_SU_Greedy)./(1:T);
plot(1:T,temp,'b--');hold on
plot(3:3:T,temp(3:3:end),'bx','MarkerSize', 10);hold on
h(7)=plot(3,temp(3),'b--x','MarkerSize', 10);hold on

h(8)=plot(1:T,cumsum(avg_SU_Randomize)./(1:T),'k-.');hold on;
h(9)=plot(1:T,cumsum(avg_SU_random)./(1:T),'k-');hold on;
ylabel({'Normalized Network Throughput';'(bits/s)/Hz/SU'});
xlabel('Time (ms)')
grid on
ylim([1.25,2.9])
ah1 = gca;
legend(ah1,h(1:3),'Location', [0.499669312169308 0.736882716049388 0.429563492063491 0.135030864197531],'{(viii)} Myopic (CSI-aided, FCFS)','{(vii)} Myopic (CSI-aided, TDFS)','{(vi)}  Myopic (CSI-aided)');
ah2=axes('position',get(gca,'position'), 'visible','off');
legend(ah2,h([4,5,7]),'Location',[0.628802910052901 0.542438271604944 0.300099206349206 0.135030864197531],'{(iv)} Myopic (FCFS)','Myopic (CA) ','{(ii)} Myopic','Location','Best',2);
ah3=axes('position',get(gca,'position'), 'visible','off');
legend(ah3,h([8,6,9]),'Location',[0.286541005291002 0.542438271604944 0.300099206349206 0.135030864197531],'(v) Randomized','(iii) Myopic (TDFS)','(i) Random','Location','Best',3);
PPP1=get(s(1),'pos');
PPP1(3)=PPP1(3)+0.04;
set(s(1),'pos',PPP1)