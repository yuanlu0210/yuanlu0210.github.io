clc;clear all;
Fdm=40;
TimeWin=0.02;
FreqSample=3;
startPnt=1e2; T=startPnt+1e3;% Change to startPnt=1e4; T=startPnt+1e5; to get exactly Fig.8 (I used HPC resouces to get these results)
Mode='VehA';
BandWRange=[25:25:200].*1e3;
nSU=3;nCh=10;
p01=0.2.*ones(1,nCh);
p11=0.8.*ones(1,nCh);
MAX=1;
Traffic=0;
Fade=cell(2);
Fade{1}=1;
avgSNRdB=10;
Fade{2}=db2pow(avgSNRdB);
Pm=0;Pf=0;
Belief=3;
for i=1:length(BandWRange)
    BandW=BandWRange(i);
    Metric=1;CSIerr=1;Randomize{1}=0;
    [resTot_CSI(i),simTot_CSI(i)]=GreedyPilot(Fdm,TimeWin,FreqSample,CSIerr,startPnt,Mode,BandW,nSU,T,nCh,p01,p11,MAX,Metric,Fade,Pm,Pf,Randomize,Belief);
    
    Metric=1;CSIerr=1;Randomize{1}=1;
    [resTot_CSI_FCFS(i),simTot_CSI_FCFS(i)]=GreedyPilot(Fdm,TimeWin,FreqSample,CSIerr,startPnt,Mode,BandW,nSU,T,nCh,p01,p11,MAX,Metric,Fade,Pm,Pf,Randomize,Belief);
    
    Metric=1;CSIerr=1;Randomize{1}=0;
    [resTot_CSI_Ideal(i),~]=GreedyPilot(Fdm,TimeWin,FreqSample,CSIerr,startPnt,Mode,BandW,nSU,T,nCh,p01,p11,MAX,Metric,Fade,Pm,Pf,Randomize,Belief);
    
    Metric=1;CSIerr=0;Randomize{1}=1;
    [resTot_CSI_FCFS_Ideal(i),~]=GreedyPilot(Fdm,TimeWin,FreqSample,CSIerr,startPnt,Mode,BandW,nSU,T,nCh,p01,p11,MAX,Metric,Fade,Pm,Pf,Randomize,Belief);
    
    Metric=0;CSIerr=1;Randomize{1}=0;
    [resTot_Greedy(i),~]=GreedyPilot(Fdm,TimeWin,FreqSample,CSIerr,startPnt,Mode,BandW,nSU,T,nCh,p01,p11,MAX,Metric,Fade,Pm,Pf,Randomize,Belief);
    
    Metric=0;CSIerr=1;Randomize{1}=1;
    [resTot_Greedy_FCFS(i),~]=GreedyPilot(Fdm,TimeWin,FreqSample,CSIerr,startPnt,Mode,BandW,nSU,T,nCh,p01,p11,MAX,Metric,Fade,Pm,Pf,Randomize,Belief);
end
%% Plot results
close all force hidden;
s(1)=subplot(2,1,1);
h(1)=plot(BandWRange./1e3,resTot_CSI_FCFS_Ideal,'r-');hold on;
h(2)=plot(BandWRange./1e3,resTot_CSI_FCFS,'r-s');hold on;
h(3)=plot(BandWRange./1e3,resTot_Greedy_FCFS,'b--s'); hold on
h(4)=plot(BandWRange./1e3,resTot_CSI_Ideal,'r--');hold on;
h(5)=plot(BandWRange./1e3,resTot_CSI,'r-x', 'Markersize',10);hold on;
h(6)=plot(BandWRange./1e3,resTot_Greedy,'b--x', 'Markersize',10); hold on
xlabel('Channel Bandwidth (kHz)')
ylabel({'Normalized Network Throughput';'(bits/s)/Hz/SU'});

set(gca,'XTick',25:25:200)
xlim([25,200])
ylim([1.5,2.8])
grid on
title('(a)')
ah1 = gca;
legend(ah1,h([1,2,3]), 'Location',[0.139233355379184 0.844444444444447 0.552221119929453 0.091966966966967],'(viii) Myopic (Ideal-CSI-aided,FCFS)','(viii) Myopic (Estimated-CSI-aided,FCFS)','(iv) Myopic (FCFS)');
ah2=axes('position',get(gca,'position'), 'visible','off');
legend(ah2,h([4,5,6]),'Location',[0.456563822751313 0.499220897253844 0.47230489417989 0.091966966966967],'(vi) Myopic (Ideal-CSI-aided)','(vi) Myopic (Estimated-CSI-aided)','(ii) Myopic')%,'FreqSample=5','FreqSample=7')

s(2)=subplot(2,1,2);
plot(BandWRange./1e3,resTot_CSI_FCFS,'r-s');hold on;
plot(BandWRange./1e3,resTot_CSI,'r-x', 'Markersize',10);hold on;
xlim([25,200])
set(gca,'XTick',25:25:200)
legend('Location',[0.139233355379184 0.283779298720179 0.552221119929453 0.0638513513513514],'(viii) Myopic (Estimated-CSI-aided,FCFS)','(vi) Myopic (Estimated-CSI-aided)','Location','Best')%,'FreqSample=5','FreqSample=7')
title('(b)')
xlabel('Channel Bandwidth (kHz)')
ylabel({'NMSE'});
grid on

