function [R,pr] =  calCorr (nCh,TimeSample,Fdm,Slot,BandW,noise_pow,Mode)
if nargin==0
    nCh=2;
    TimeSample=4;
    pilot_SNR=30;
    Fdm=50;
    Slot=1e-3;
    BandW=200e3;
    noise_pow=1/(10^(pilot_SNR/10));
    Mode='PedB';
end

switch Mode
    case 'PedB'
        PedB_Delay=[0 200e-9 800e-9 1200e-9 2300e-9 3700e-9];
        PedB_AmpdB=[0 -0.9 -4.9 -8 -7.8 -23.9];PedB_Amp=db2mag(PedB_AmpdB);
        for m=0:nCh-1
            corrFreq(m+1)=sum(PedB_Amp.^2.*exp(-1j*2*pi.*m.*BandW.*PedB_Delay));
        end
    case 'VehB'
        VehB_Delay=[0 300e-9 8900e-9 12900e-9 17100e-9 20000e-9];
        VehB_AmpdB=[-2.5 0 -12.8 -10.0 -25.2 -16.0]; VehB_Amp=db2mag(VehB_AmpdB);
        for m=0:nCh-1
            corrFreq(m+1)=sum(VehB_Amp.^2.*exp(-1j*2*pi.*m.*BandW.*VehB_Delay));
        end
    case 'VehA'
        VehA_Delay=[0 310e-9 710e-9 1090e-9 1730e-9 2510e-9];
        VehA_AmpdB=[0 -1 -9 -10 -15 -20]; VehA_Amp=db2mag(VehA_AmpdB);
        for m=0:nCh-1
            corrFreq(m+1)=sum(VehA_Amp.^2.*exp(-1j*2*pi.*m.*BandW.*VehA_Delay));
        end
end
corrFreq=corrFreq./corrFreq(1);
corrTime=besselj(0,2.*pi.*Fdm.*(0:TimeSample-1).*Slot);
prt=besselj(0,2.*pi.*Fdm.*((0:TimeSample-1).*Slot+Slot));
pr=zeros(TimeSample.*nCh,nCh);
R=kron(conj(toeplitz(corrFreq)),toeplitz(corrTime))+noise_pow.*eye(nCh.*TimeSample);
corrFreqtot=toeplitz(corrFreq);
for ii=1:nCh
pr(:,ii)=kron(corrFreqtot(ii,:),prt).';
end