function [Pred,rho]= CSIest (Coeftemp, R, pr, indexlr)
Rcut=R(indexlr,indexlr);
prcut=pr(indexlr);
PredCoefcut=Rcut\prcut;
rho=prcut'*PredCoefcut;
Pred=Coeftemp(indexlr)'*PredCoefcut;


