function [C_hat,sumpdferr]=CapEst(rho,SNR_hat,avgSNR)
if rho<=0.9
    if SNR_hat<100
    MaxSNR=(1-rho).*100+SNR_hat.*4;
    else
        MaxSNR=450+SNR_hat;
    end
    SNRrange=linspace(0,MaxSNR,4001);
%     x=2.*sqrt(SNRrange.*SNR_hat)./avgSNR./(1-rho);
%     conditionPDF=1./avgSNR./(1-rho).*besseli(0,x).*exp(-1./avgSNR/(1-rho).*(SNRrange+SNR_hat));
elseif rho>0.9&&rho<=0.99
    if SNR_hat<=10
        MaxSNR=(1-rho).*100+SNR_hat.*4;
    elseif SNR_hat>10&&SNR_hat<100
        MaxSNR=ceil(SNR_hat)+70;
    else
        MaxSNR=450+SNR_hat;
    end
    SNRrange=linspace(0,MaxSNR,4001);
    
%     if SNR_hat<=10
%         x=2.*sqrt(SNRrange.*SNR_hat)./avgSNR./(1-rho);
%         conditionPDF=1./avgSNR./(1-rho).*besseli(0,x).*exp(-1./avgSNR/(1-rho).*(SNRrange+SNR_hat));
%      elseif SNR_hat>10&&SNR_hat<100
%         SNRrange=SNRrange(2:end);
%         x=2.*sqrt(SNRrange.*SNR_hat)./avgSNR./(1-rho);
%         y=(2.*sqrt(SNRrange.*SNR_hat)-SNRrange-SNR_hat)./avgSNR./(1-rho);
%         conditionPDF=1./avgSNR./(1-rho).*exp(y)./sqrt(2*pi*x).*(1+1./(8*x)+9./(128*x.^2)+225./(3072*x.^3)+11025./(98304*x.^4));
%     else
%         conditionPDF=calconditionalPDF(SNRrange,avgSNR,SNR_hat,rho);
%     end
elseif rho>0.99&&rho<=0.999
    if SNR_hat<=1
        MaxSNR=(1-rho).*100+SNR_hat.*4;
    else
        MaxSNR=ceil(SNR_hat)+2000.*avgSNR.*(1-rho)+60;
    end
    SNRrange=linspace(0,MaxSNR,4001);
%     if SNR_hat<=1
%         x=2.*sqrt(SNRrange.*SNR_hat)./avgSNR./(1-rho);
%         conditionPDF=1./avgSNR./(1-rho).*besseli(0,x).*exp(-1./avgSNR/(1-rho).*(SNRrange+SNR_hat));
%     else
%         SNRrange=SNRrange(2:end);
%         x=2.*sqrt(SNRrange.*SNR_hat)./avgSNR./(1-rho);
%         y=(2.*sqrt(SNRrange.*SNR_hat)-SNRrange-SNR_hat)./avgSNR./(1-rho);
%         conditionPDF=1./avgSNR./(1-rho).*exp(y)./sqrt(2*pi*x).*(1+1./(8*x)+9./(128*x.^2)+225./(3072*x.^3)+11025./(98304*x.^4));
%     end
elseif rho>0.999
    if SNR_hat<=0.3
        MaxSNR=150-150*rho+4*SNR_hat;
    else
        MaxSNR=1.1*SNR_hat+1.1;
    end
    SNRrange=linspace(0,MaxSNR,4001);
%     if SNR_hat>0.3
%         SNRrange=SNRrange(2:end);
%     end
%     conditionPDF=calconditionalPDF(SNRrange,avgSNR,SNR_hat,rho);
end
conditionPDF=calconditionalPDF(SNRrange,avgSNR,SNR_hat,rho);
C_hat=trapz(conditionPDF.*log2(1+SNRrange)).*(SNRrange(2)-SNRrange(1));
sumpdf2=trapz(conditionPDF).*(SNRrange(2)-SNRrange(1));
if abs(sumpdf2-1)>0.001||~isfinite(sumpdf2)
    error(['the contional pdf does not intergrate to 1 with [abs(sumpdf2-1),rho,SNR_hat]=[' num2str(abs(sumpdf2-1)) ', ' num2str(rho) ', ' num2str(SNR_hat) ']']);
end