% clc;clear;close all;
%Metric------[0]:Bandwidth
%Metric------[1]:Capacity
%Metric------[2]:Rate under ContinuousAM
%Reward------[0]:Bandwidth
%Reward------[1]:Capacity
%Reward------[2]:Rate under ContinuousAM
%Fade--------[1]:Rayleigh Fade
%Fade--------[2]:Correlated Shadow Fade
%Randomize{1}---[0]:Not Randomized
%Randomize{1}---[1]:Randomized
%Randomize{1}---[2]:FCFS
%Randomize{1}---[3]:TDFS
%Randomize{1}---[4]:CA (Randomize{1,2}=NCCmin,NCCmax)
%Belief------[0]No Belief Update (Random Selection)
%Belief------[3]Belief Update
%varargin--[avgSNR] or [mu,SIGMA]:Paramaters for Correlated Shadowing
function [avg_SU,avg_PU,avg_Se] = Greedy(nSU,T,nCh,p01,p11,MAX,Metric,Reward,Fade,Pm,Pf,Randomize,Belief,varargin)
initialBelief = p01 ./ ( 1 + p01 - p11 );
reward = zeros(nSU,T);
reward_PU=zeros(1,T);
if Randomize{1}==4
    NCCmin=Randomize{2};
    NCCmax=Randomize{3};
    NCC=NCCmin.*ones(1,nSU);
end
for k = 1 : MAX
    
    uniformRV = rand( T + 1, nCh );
    channelState = ( uniformRV(1,:) < initialBelief );
    if Belief==3
        belief=ones(nSU, 1) * initialBelief;
    end
    switch Fade{1}
        case 1
            avgSNR=Fade{2};
            SNR=exprnd(avgSNR,nSU,nCh);
            SNR_PU=exprnd(avgSNR,1,nCh);
        case 2
            mu=Fade{2};
            SIGMA=Fade{3};
            X = mvnrnd(mu,SIGMA,nCh) ;
            SNR=db2pow(X');
            X_PU = normrnd(mu(1),sqrt(SIGMA(1,1)),1,nCh) ;
            SNR_PU=db2pow(X_PU);
    end
    switch Metric
        case 0
        case {1,3}
            C= log2(1+SNR);
            C_PU= log2(1+SNR_PU);
        case 2
            BERTarget=1e-3;
            Rate=log2(1-1.5.*SNR./log(BERTarget./0.2));
    end
    switch Reward
        case 0
        case 1
            C= log2(1+SNR);
            C_PU= log2(1+SNR_PU);
        case 2
            BERTarget=1e-3;
            Rate=log2(1-1.5.*SNR./log(BERTarget./0.2));
            Rate_PU=log2(1-1.6.*SNR_PU./log(BERTarget./0.2));
    end
    for t = 1 : T
        sensingAction=zeros(1,nSU);
        sensingOutcome=zeros(1,nSU);
        switch Reward
            case 0
                reward_PU(t) = reward_PU(t) + sum((1 - channelState));
            case 1
                reward_PU(t) = reward_PU(t) + sum((1 - channelState) .* C_PU);
            case 2
                reward_PU(t) = reward_PU(t) + sum((1 - channelState) .* Rate_PU);
        end
        if Randomize{1}==2
            userRank=randperm(nSU);
            remainingChannel=ones(1,nCh);
        end
        for i = 1 : nSU
            if Randomize{1}==2
                i=userRank(i);
            end
            switch Belief
                case 0
                    immediateReward=randperm(nCh);
                case 3
                    idleProb = belief(i,:) .* p11 + (1 - belief(i,:)) .* p01;
                    immediateReward=idleProb;
            end
            switch Metric
                case 0
                case 1
                    immediateReward = immediateReward .*  C(i,:);
                case 2
                    immediateReward = immediateReward .*  Rate(i,:);
                case 3
                    immediateReward =   C(i,:);
            end
            switch Randomize{1}
                case 0
                    [tmp, sensingAction(i)] = max( immediateReward );
                    isTie = find( immediateReward == tmp );
                    if(length(isTie) > 1)
                        sensingAction(i) = isTie(ceil(rand(1) * length(isTie)));
                    end
                case 1
                    Prob=immediateReward/sum(immediateReward);
                    CDF=cumsum([0,Prob]);
                    sensingAction(i)=max(find(CDF<rand(1)));
                case 2
                    
                    [tmp, sensingAction(i)] = max( immediateReward.*remainingChannel );
                    isTie = find( immediateReward.*remainingChannel == tmp );
                    if(length(isTie) > 1)
                        sensingAction(i) = isTie(ceil(rand(1) * length(isTie)));
                    end
                    if tmp==0
                        sensingAction(i)=0;
                    end
                    if sensingAction(i)~=0
                        remainingChannel(1,sensingAction(i))=0;
                    end
                case 3
                    Rank=mod(t+i-1-1,nSU)+1;
                    [~,SortedInd]=sort(immediateReward,'Descend');
                    isTie = find( immediateReward == immediateReward(SortedInd(Rank)));
                    sensingAction(i) = SortedInd(Rank);
                    if(length(isTie) > 1)
                        sensingAction(i) = isTie(ceil(rand(1) * length(isTie)));
                    end
                case 4
                    [x,ind]=sort( immediateReward,'descend');
                    isTie = find( immediateReward>= x(NCC(i)) );
                    sensingAction(i) = isTie(randi( length(isTie)));
            end
            sensingOutcome(i)=(channelState(sensingAction(i))==0)*(rand(1)<= Pm)+(channelState(sensingAction(i))== 1)*(rand(1)<= 1 - Pf);
            if Belief==3
                belief(i,:) = idleProb;
                if sensingOutcome(i)==1
                    belief(i,sensingAction(i))=(1-Pf) * idleProb(sensingAction(i)) ...
                        / ((1-Pf) * idleProb(sensingAction(i)) + Pm*(1 - idleProb(sensingAction(i))));
                else
                    belief(i,sensingAction(i)) = Pf * idleProb(sensingAction(i)) ...
                        / (Pf * idleProb(sensingAction(i)) + (1-Pm)*(1 - idleProb(sensingAction(i))));
                end
            end
        end
        
        for i = 1 : nCh
            temp=abs(sensingAction-i)+abs(sensingOutcome-1);
            competingUsers=find(temp==0);
            if Randomize{1}==4
                if length(competingUsers)>1
                    NCC(competingUsers)=NCC(competingUsers)+1;
                    NCC( NCC>NCCmax)=NCCmax;
                elseif length(competingUsers)==1
                    NCC(competingUsers)=NCCmin;
                end
            end
            if( ~isempty(competingUsers) )
                id = competingUsers(ceil( rand(1) * length(competingUsers)));
                if (channelState(sensingAction(id))==1)&& sensingOutcome(id)==1
                    switch Reward
                        case 0
                            reward (id,t)= reward(id,t) +1;
                        case 1
                            reward (id,t)= reward(id,t) +C(id,sensingAction(id));
                        case 2
                            reward (id,t)= reward(id,t) +Rate(id,sensingAction(id));
                    end
                end
                switch Reward
                    case 0
                        reward_PU(t) =  reward_PU (t)- sensingOutcome(id) * (1 - channelState(sensingAction(id))) * 1;
                    case 1
                        reward_PU(t) =  reward_PU (t)- sensingOutcome(id) * (1 - channelState(sensingAction(id))) * C_PU(sensingAction(id));
                    case 2
                        reward_PU(t) =  reward_PU (t)- sensingOutcome(id) * (1 - channelState(sensingAction(id))) * Rate_PU(sensingAction(id));
                end
            end
        end
        channelState = channelState .* ( uniformRV(t+1, :) < p11 )  + (1 - channelState) .* ( uniformRV(t+1, :) < p01 );
    end
end
avg_SU =sum(reward,1)./ MAX./nSU;
avg_PU=reward_PU./ MAX./nCh;
avg_Se = avg_SU+avg_PU;