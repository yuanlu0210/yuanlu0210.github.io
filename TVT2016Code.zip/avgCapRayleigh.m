function avgCap=avgCapRayleigh(avgSNR)
SNRrange=linspace(0,1000,4001);
PDF=1./avgSNR.*exp(-SNRrange./avgSNR);
avgCap=trapz(PDF.*log2(1+SNRrange)).*(SNRrange(2)-SNRrange(1));
