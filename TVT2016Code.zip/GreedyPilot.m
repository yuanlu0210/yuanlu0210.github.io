% clc;clear;close all;
%Traffic-----[0]:Backlogged
%Traffic-----[1,pktArrivalRate]:Poisson Traffic
%Metric------[0]:Bandwidth
%Metric------[1]: Capacity
%Fade--------[0]:No Fade
%Fade--------[1]:Rayleigh Fade
%Fade--------[2]:Correlated Shadow Fade
%Randomize---[0]:Not Randomized
%Randomize---[1]:Randomized
%Belief------[0]No Belief Update, Random Selection
%Belief------[1]Real 1st Order Statistics
%Belief------[2]Track 1st Order Statistics
%Belief------[3]2nd Order Belief Update according to the sensing outcome
%Belief------[4]2nd Order Belief Update according to ACK
%Belief------[5]Negotiate
%varargin--[avgSNR] or [mu,SIGMA]:Paramaters for Correlated Shadowing

%%
function [res,mse] =GreedyPilot(Fdm,TimeWin,FreqSample,CSIerr,startPnt,Mode,BandW,nSU,T,nCh,p01,p11,MAX,Metric,Fade,Pm,Pf,Randomize,Belief,varargin);
initialBelief = p01 ./ ( 1 + p01 - p11 );
reward = zeros(nSU,T);
reward_PU=zeros(1,T);

rho=zeros(nCh,T,nSU);
Pred=zeros(nCh,T,nSU);
Slot=1e-3;
TimeSample=round(TimeWin./Slot);FreqWing=(FreqSample-1)./2;

PilotLoclr=zeros(nCh,TimeSample);
uniformRV = rand( T + 1, nCh );
channelState = ( uniformRV(1,:) < initialBelief );
if Belief==3
    belief=ones(nSU, 1) * initialBelief;
end
switch Fade{1}
    case 1
        avgSNR=Fade{2};
        noise_pow=1/(10^(avgSNR/10));
        [R,pr]=calCorr (nCh,TimeSample,Fdm,Slot,BandW,noise_pow,Mode);
        if CSIerr(1)==1
            Coef= CSIgen (nCh,T,nSU,Fdm,Slot,BandW,Mode);
            SNR=abs(Coef).^2.*avgSNR;
            SNR=permute(SNR,[3,1,2]);
            NoisyCoef=Coef+ randn(nCh,T,nSU).*sqrt(noise_pow/2)+1j.*randn(nCh,T,nSU).*sqrt(noise_pow/2);
            C= log2(1+SNR);
        else
            Coef= CSIgen (nCh,T,nSU,Fdm,Slot,BandW,Mode);
            SNRtemp=abs(Coef).^2.*avgSNR;
            SNRtot=permute(SNRtemp,[3,1,2]);
        end
    case 2
        mu=Fade{2};
        SIGMA=Fade{3};
        X = mvnrnd(mu,SIGMA,nCh) ;
        SNR=db2pow(X');
        X_PU = normrnd(mu(1),sqrt(SIGMA(1,1)),1,nCh) ;
        SNR_PU=db2pow(X_PU);
end
%%   Filter Coefficient Dataset Test
for t = 1:T
    if t==startPnt+1
        belief=ones(nSU, 1) * initialBelief;
    end
    sensingAction=zeros(1,nSU);
    sensingOutcome=zeros(1,nSU);
    switch Fade{1}
        case 1
            if CSIerr(1)==1 && t>TimeSample
                for ii=1:nSU
                    Bufferlr=fliplr(NoisyCoef(:,:,ii));
                    for jj=1:nCh
                        FreqLower=max(1,jj-FreqWing);
                        FreqUpper=min(nCh,jj+FreqWing);
                        Coeftemp=reshape(Bufferlr(FreqLower:FreqUpper,T-t+2:T-t+TimeSample+1)',TimeSample.*(FreqUpper-FreqLower+1),1);
                        PilotLoclrReshape=reshape(PilotLoclr(FreqLower:FreqUpper,:),TimeSample.*(FreqUpper-FreqLower+1),1);
                        indexlr=find(PilotLoclrReshape~=0);
                        [Pred(jj,t,ii),rho(jj,t,ii)]= CSIest (Coeftemp, R((FreqLower-1)*TimeSample+1:FreqUpper*TimeSample,(FreqLower-1)*TimeSample+1:FreqUpper*TimeSample), pr((FreqLower-1)*TimeSample+1:FreqUpper*TimeSample,jj), indexlr);
                        SNR_hat(ii,jj,t)=abs(Pred(jj,t,ii)).^2.*avgSNR;
                        C_hat(ii,jj,t)= CapEst(rho(jj,t,ii),SNR_hat(ii,jj,t),avgSNR);
                    end
                end
                C_hat=C_hat;
            elseif CSIerr(1)==1 && t<=TimeSample
                C_hat=avgCapRayleigh(avgSNR);
                C_hat=ones(nSU,nCh,T).*C_hat;
            else
                C= log2(1+SNRtot(:,:,t));
            end
        case 2
            C=log2(1+SNR);
    end
    if Randomize{1}==2
        userRank=randperm(nSU);
        remainingChannel=ones(1,nCh);
    end
    for i = 1 : nSU
        if Randomize{1}==2
            i=userRank(i);
        end
        switch Belief
            case 0
                immediateReward=randperm(nCh);
            case 3
                idleProb = belief(i,:) .* p11 + (1 - belief(i,:)) .* p01;
                immediateReward=idleProb;
        end
        switch Metric
            case 0
            case 1
                if CSIerr(1)==1
                    immediateReward = immediateReward .*  C_hat(i,:,t);
                else
                    immediateReward = immediateReward .*  C(i,:);
                end
        end
            switch Randomize{1}
                case 0
                    [tmp, sensingAction(i)] = max( immediateReward );
                    isTie = find( immediateReward == tmp );
                    if(length(isTie) > 1)
                        sensingAction(i) = isTie(ceil(rand(1) * length(isTie)));
                    end
                case 1
                    Prob=immediateReward/sum(immediateReward);
                    CDF=cumsum([0,Prob]);
                    sensingAction(i)=max(find(CDF<rand(1)));
                case 2
                    [tmp, sensingAction(i)] = max( immediateReward.*remainingChannel );
                    isTie = find( immediateReward.*remainingChannel == tmp );
                    if(length(isTie) > 1)
                        sensingAction(i) = isTie(ceil(rand(1) * length(isTie)));
                    end
                    if tmp==0
                        sensingAction(i)=0;
                    end
                    if sensingAction(i)~=0
                        remainingChannel(1,sensingAction(i))=0;
                    end
            end
        
        sensingOutcome(i)=(channelState(sensingAction(i))==0)*(rand(1)<= Pm)+(channelState(sensingAction(i))== 1)*(rand(1)<= 1 - Pf);
        if Belief==3
            belief(i,:) = idleProb;
            if sensingOutcome(i)==1
                belief(i,sensingAction(i))=(1-Pf) * idleProb(sensingAction(i)) ...
                    / ((1-Pf) * idleProb(sensingAction(i)) + Pm*(1 - idleProb(sensingAction(i))));
            else
                belief(i,sensingAction(i)) = Pf * idleProb(sensingAction(i)) ...
                    / (Pf * idleProb(sensingAction(i)) + (1-Pm)*(1 - idleProb(sensingAction(i))));
            end
        end
    end
    if CSIerr(1)==1
        PilotLoclr=[zeros(nCh,1) PilotLoclr(:,1:end-1)];
    end
    for i = 1 : nCh
        temp=abs(sensingAction-i)+abs(sensingOutcome-1);
        competingUsers=find(temp==0);
        if( ~isempty(competingUsers) )
            id = competingUsers(ceil( rand(1) * length(competingUsers)));
            if (channelState(sensingAction(id))==1)&& sensingOutcome(id)==1
                switch Fade{1}
                    case 0
                        reward (id,t)= reward(id,t) +1;
                        
                    otherwise
                        if CSIerr(1)==1
                            reward (id,t)= reward(id,t) +C(id,sensingAction(id),t);
                            PilotLoclr(i,1)=1;
                        else
                            reward (id,t)= reward(id,t) +C(id,sensingAction(id));
                        end
                end
            end
        end
    end
    
    channelState = channelState .* ( uniformRV(t+1, :) < p11 )  + (1 - channelState) .* ( uniformRV(t+1, :) < p01 );
end
avg_SU =sum(reward,1)./ MAX./nSU;

%%
res=sum(avg_SU(startPnt+1:end))./(T-startPnt);
mse_sim=zeros(nCh,nSU);
for ii=1:nSU
    for jj=1:nCh
        cutPred=Pred(jj,startPnt+1:end,ii);
        cutCoef=Coef(jj,startPnt+1:end,ii);
        difference=cutPred-cutCoef;
        mse_sim(jj,ii)=var(difference(:));
    end
end
mse=mean(mean(mse_sim));